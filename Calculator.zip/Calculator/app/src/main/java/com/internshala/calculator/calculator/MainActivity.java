package com.internshala.calculator.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,badd,bsub,bmul,bdiv,bclear,bce,bequal;
    TextView textinput, textresult;
    String s = "", s1 = "", s2="", resultstring = "";
    int i = 0, i1 = 0, c = -1;
    int result = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);
        b5 = (Button) findViewById(R.id.b5);
        b6 = (Button) findViewById(R.id.b6);
        b7 = (Button) findViewById(R.id.b7);
        b8 = (Button) findViewById(R.id.b8);
        b9 = (Button) findViewById(R.id.b9);
        b0 = (Button) findViewById(R.id.b0);
        badd = (Button) findViewById(R.id.badd);
        bsub = (Button) findViewById(R.id.bsub);
        bmul = (Button) findViewById(R.id.bmul);
        bdiv = (Button) findViewById(R.id.bdiv);
        bclear = (Button) findViewById(R.id.bclear);
        bequal = (Button) findViewById(R.id.bequal);
        bce = (Button) findViewById(R.id.bce);

        textinput = (TextView)findViewById(R.id.textView2);
        textresult = (TextView)findViewById(R.id.textView);

        b1.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "1");
            s = "";
        });

        b2.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "2");
            s = "";
        });

        b3.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "3");
            s = "";
        });

        b4.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "4");
            s = "";
        });

        b5.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "5");
            s = "";
        });

        b6.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "6");
            s = "";
        });

        b7.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "7");
            s = "";
        });

        b8.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "8");
            s = "";
        });

        b9.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "9");
            s = "";
        });

        b0.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*")) {
                textresult.setText("");
                s = "";
            }
            textresult.setText(s + "0");
            s = "";
        });

        badd.setOnClickListener((v) -> {
            String tmp = (String) textresult.getText();
            if(tmp.isEmpty())
            {
                s1 = "0";
            } else if(!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*") && !tmp.equals("/"))
            {
                s1 = tmp;
            }
            c = 0;
            resultstring = "";
            textresult.setText("+");
            textinput.setText(s1 + " + ");
        });

        bsub.setOnClickListener((v) -> {
            String tmp = (String) textresult.getText();
            if(tmp.isEmpty())
            {
                s1 = "0";
            } else if(!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*") && !tmp.equals("/"))
            {
                s1 = tmp;
            }
            c = 1;
            resultstring = "";
            textresult.setText("-");
            textinput.setText(s1 + " - ");
        });

        bdiv.setOnClickListener((v) -> {
            String tmp = (String) textresult.getText();
            if(tmp.isEmpty())
            {
                s1 = "0";
            } else if(!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*") && !tmp.equals("/"))
            {
                s1 = tmp;
            }
            c = 2;
            resultstring = "";
            textresult.setText("/");
            textinput.setText(s1 + " / ");
        });

        bmul.setOnClickListener((v) -> {
            String tmp = (String) textresult.getText();
            if(tmp.isEmpty())
            {
                s1 = "0";
            } else if(!tmp.equals("+") && !tmp.equals("-") && !tmp.equals("*") && !tmp.equals("/"))
            {
                s1 = tmp;
            }
            c = 3;
            resultstring = "";
            textresult.setText("*");
            textinput.setText(s1 + " * ");
        });

        bequal.setOnClickListener((v) -> {
            String operator = "";
            if(s1.equalsIgnoreCase("+") || s1.equalsIgnoreCase("-") || s1.equalsIgnoreCase("/") || s1.equalsIgnoreCase("*"))
            {
                i = 0;
            } else if(s1 == null || s1.isEmpty())
            {
                i = 0;
            } else {
                i = Integer.parseInt(s1);
            }

            if(resultstring.isEmpty())
            {
                s2 = (String) textresult.getText();
                if(s2.equalsIgnoreCase("+") || s2.equalsIgnoreCase("-") || s2.equalsIgnoreCase("/") || s2.equalsIgnoreCase("*"))
                {
                    i1 = 0;
                } else if(s2 == null || s2.isEmpty())
                {
                    i1 = 0;
                } else {
                    i1 = Integer.parseInt(s2);
                }
            }  else{
                i = result;
            }

            if(c == 0) {
                operator = "+";
                result = i + i1;
            }  else if(c == 1) {
                operator = "-";
                result = i - i1;
            }  else if(c == 2) {
                operator = "/";
                if(i1 == 0)
                {
                    Toast.makeText(getApplicationContext(),"invalid input", Toast.LENGTH_LONG).show();
                    result = 0;
                }
                else {
                    result = i / i1;
                }
            }  else if(c == 3) {
                operator = "*";
                result = i * i1;
            }  else {
                operator = "";
                result = 0;
            }

            if(!operator.isEmpty())
            {
                textinput.setText(i + " " + operator + " " + i1);
            }  else
            {
                textinput.setText("");
            }

            resultstring = String.valueOf(result);
            textresult.setText(resultstring);

        });

        bclear.setOnClickListener((v) -> {
            s = (String) textresult.getText();
            if (s.equals("+") || s.equals("-") || s.equals("/") || s.equals("*") || s.equals(""))
            {
                i = 0;
            } else {
                i = Integer.parseInt(s);
                i = i/10;
            }
            if(i == 0)  {
                textresult.setText("");
            }  else{
                textresult.setText(i + "");
            }
            s = null;

        });

        bce.setOnClickListener((v) -> {
            textresult.setText("");
            textinput.setText("");
            i = 0;
            i1 = 0;
            s1 = "";
            s2 = "";
            resultstring = "";
            c = -1;
            result = 0;
        });







    }
}
